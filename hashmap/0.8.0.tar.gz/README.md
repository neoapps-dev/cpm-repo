repo url: https://github.com/tidwall/hashmap.c
