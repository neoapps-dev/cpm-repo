#ifndef LIBFOO_H
#define LIBFOO_H

int add(int a, int b);

#endif

